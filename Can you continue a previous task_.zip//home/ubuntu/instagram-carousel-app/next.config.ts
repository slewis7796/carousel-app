import { withSentryConfig } from "@sentry/nextjs";
import { OpenNextConfig } from "open-next/types";

const config = {
  output: 'export',
  distDir: 'out',
  images: {
    unoptimized: true,
  },
} satisfies OpenNextConfig;

export default withSentryConfig(config, {
  silent: true,
});
