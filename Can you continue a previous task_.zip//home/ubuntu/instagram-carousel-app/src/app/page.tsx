'use client';

import { useState, useRef, useEffect } from 'react';
import Head from 'next/head';
import html2canvas from 'html2canvas';
import JSZip from 'jszip';
import { saveAs } from 'file-saver';

// Define font options with display names and CSS class names
const fontOptions = [
  { name: 'Montserrat', class: 'font-montserrat' },
  { name: 'Open Sans', class: 'font-opensans' },
  { name: 'Raleway', class: 'font-raleway' },
  { name: 'Nunito', class: 'font-nunito' },
  { name: 'Source Serif Pro', class: 'font-source-serif-pro' },
  { name: 'Poppins', class: 'font-poppins' },
  { name: 'Oswald', class: 'font-oswald' },
  // Playful fonts
  { name: 'Pacifico', class: 'font-pacifico' },
  { name: 'Lobster', class: 'font-lobster' },
  { name: 'Permanent Marker', class: 'font-permanent-marker' },
  { name: 'Fredoka One', class: 'font-fredoka-one' },
  // Impactful fonts
  { name: 'Bebas Neue', class: 'font-bebas-neue' },
  { name: 'Anton', class: 'font-anton' },
  { name: 'Abril Fatface', class: 'font-abril-fatface' },
  { name: 'Righteous', class: 'font-righteous' },
  { name: 'Cormorant Garamond', class: 'font-cormorant-garamond' },
  { name: 'Didot', class: 'font-didot' },
];

// Color options
const colorOptions = [
  { name: 'White', value: '#ffffff' },
  { name: 'Black', value: '#000000' },
  { name: 'Gray', value: '#4b5563' },
  { name: 'Light Gray', value: '#9ca3af' },
  { name: 'Silver', value: '#d1d5db' },
  { name: 'Yellow', value: '#fbbf24' },
  { name: 'Teal', value: '#14b8a6' },
  { name: 'Green', value: '#22c55e' },
  { name: 'Red', value: '#ef4444' },
  { name: 'Blue', value: '#3b82f6' },
  // Added requested colors
  { name: 'Light Blue', value: '#1DA1DC' },
  { name: 'Lime Green', value: '#A8CF45' },
  { name: 'Orange', value: '#F99B1C' },
  { name: 'Pink', value: '#EF5DA2' },
];

// Maximum word count
const MAX_WORDS = 270;

// Instagram carousel dimensions (4:5 aspect ratio)
const CAROUSEL_DIMENSIONS = {
  width: 1080,
  height: 1350
};

export default function Home() {
  // State for initial carousel setup
  const [inputText, setInputText] = useState('');
  const [backgroundColor, setBackgroundColor] = useState('#ffffff');
  const [fontStyle, setFontStyle] = useState(fontOptions[0]);
  const [fontColor, setFontColor] = useState('#000000');
  const [logoImage, setLogoImage] = useState<string | null>(null);
  const [wordCount, setWordCount] = useState(0);
  
  // State for generated slides
  const [slides, setSlides] = useState<string[]>([]);
  const [hasCoverSlide, setHasCoverSlide] = useState(false);
  const [coverTitle, setCoverTitle] = useState('');
  const [coverImage, setCoverImage] = useState<string | null>(null);
  
  // State for app flow
  const [isGenerating, setIsGenerating] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);
  
  // Refs
  const logoInputRef = useRef<HTMLInputElement>(null);
  const coverImageInputRef = useRef<HTMLInputElement>(null);
  const slidesRef = useRef<(HTMLDivElement | null)[]>([]);
  
  // Effect to count words
  useEffect(() => {
    if (inputText.trim() === '') {
      setWordCount(0);
      return;
    }
    
    const words = inputText.trim().split(/\s+/);
    setWordCount(words.length);
  }, [inputText]);
  
  // Effect to preload fonts
  useEffect(() => {
    // This ensures fonts are loaded when the component mounts
    document.body.classList.add('fonts-loaded');
    
    // Create link elements for each font to ensure they're loaded
    fontOptions.forEach(font => {
      const fontName = font.name.replace(/\s+/g, '+');
      const link = document.createElement('link');
      link.href = `https://fonts.googleapis.com/css2?family=${fontName}:wght@400;700&display=swap`;
      link.rel = 'stylesheet';
      document.head.appendChild(link);
    });
  }, []);
  
  // Handle logo upload
  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const reader = new FileReader();
      
      reader.onload = (event) => {
        if (event.target && typeof event.target.result === 'string') {
          setLogoImage(event.target.result);
        }
      };
      
      reader.readAsDataURL(file);
    }
  };
  
  // Handle cover image upload
  const handleCoverImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const reader = new FileReader();
      
      reader.onload = (event) => {
        if (event.target && typeof event.target.result === 'string') {
          setCoverImage(event.target.result);
        }
      };
      
      reader.readAsDataURL(file);
    }
  };
  
  // Handle font selection
  const handleFontChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const selectedFont = fontOptions.find(font => font.name === e.target.value);
    if (selectedFont) {
      setFontStyle(selectedFont);
    }
  };
  
  // Click handler for logo upload area
  const handleLogoAreaClick = () => {
    if (logoInputRef.current) {
      logoInputRef.current.click();
    }
  };
  
  // Click handler for cover image upload area
  const handleCoverImageAreaClick = () => {
    if (coverImageInputRef.current) {
      coverImageInputRef.current.click();
    }
  };
  
  // Generate carousel slides from input text
  const generateSlides = () => {
    if (inputText.trim() === '') {
      alert('Please enter some text to generate slides.');
      return;
    }
    
    if (wordCount > MAX_WORDS) {
      alert(`Text exceeds maximum word count of ${MAX_WORDS}. Please reduce the text.`);
      return;
    }
    
    // Split text into sentences
    const sentences = inputText.match(/[^.!?]+[.!?]+/g) || [inputText];
    
    // Group sentences into slides (max 9 slides)
    const maxSlides = 9;
    const sentencesPerSlide = Math.ceil(sentences.length / maxSlides);
    
    const generatedSlides: string[] = [];
    
    for (let i = 0; i < sentences.length; i += sentencesPerSlide) {
      const slideContent = sentences.slice(i, i + sentencesPerSlide).join(' ');
      generatedSlides.push(slideContent);
      
      if (generatedSlides.length >= maxSlides) {
        break;
      }
    }
    
    setSlides(generatedSlides);
    setIsGenerating(true);
    setIsEditing(true);
  };
  
  // Add a new empty slide
  const addSlide = () => {
    if (slides.length >= 9) {
      alert('Maximum of 9 slides reached.');
      return;
    }
    
    setSlides([...slides, '']);
  };
  
  // Delete a slide
  const deleteSlide = (index: number) => {
    const newSlides = [...slides];
    newSlides.splice(index, 1);
    setSlides(newSlides);
  };
  
  // Update slide content
  const updateSlideContent = (index: number, content: string) => {
    const newSlides = [...slides];
    newSlides[index] = content;
    setSlides(newSlides);
  };
  
  // Toggle cover slide
  const toggleCoverSlide = () => {
    setHasCoverSlide(!hasCoverSlide);
  };
  
  // Calculate dynamic font size based on text length
  const calculateFontSize = (text: string) => {
    if (!text) return 48; // Increased default size
    
    const length = text.length;
    
    if (length < 50) return 48;
    if (length < 100) return 42;
    if (length < 200) return 36;
    if (length < 300) return 30;
    return 24;
  };
  
  // Direct canvas rendering for slide
  const renderSlideToCanvas = (content: string, index: number): Promise<Blob> => {
    return new Promise((resolve) => {
      // Create canvas with Instagram dimensions
      const canvas = document.createElement('canvas');
      canvas.width = CAROUSEL_DIMENSIONS.width;
      canvas.height = CAROUSEL_DIMENSIONS.height;
      const ctx = canvas.getContext('2d');
      
      if (!ctx) {
        console.error('Could not get canvas context');
        resolve(new Blob([]));
        return;
      }
      
      // Fill background
      ctx.fillStyle = backgroundColor;
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      
      // Set up text properties
      const fontSize = calculateFontSize(content);
      ctx.font = `${fontSize}px ${fontStyle.name}`;
      ctx.fillStyle = fontColor;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      
      // Wrap and draw text
      const maxWidth = canvas.width * 0.8;
      const lineHeight = fontSize * 1.2;
      const words = content.split(' ');
      let line = '';
      let lines = [];
      
      for (let i = 0; i < words.length; i++) {
        const testLine = line + words[i] + ' ';
        const metrics = ctx.measureText(testLine);
        const testWidth = metrics.width;
        
        if (testWidth > maxWidth && i > 0) {
          lines.push(line);
          line = words[i] + ' ';
        } else {
          line = testLine;
        }
      }
      lines.push(line);
      
      // Calculate total text height
      const totalTextHeight = lines.length * lineHeight;
      let textY = (canvas.height - totalTextHeight) / 2 + fontSize / 2;
      
      // Draw each line
      for (let i = 0; i < lines.length; i++) {
        ctx.fillText(lines[i], canvas.width / 2, textY);
        textY += lineHeight;
      }
      
      // Add logo if exists
      if (logoImage) {
        const logo = new Image();
        logo.onload = () => {
          // Calculate logo dimensions (75px height with proportional width)
          const logoHeight = 75;
          const logoWidth = (logo.width / logo.height) * logoHeight;
          
          // Position logo in bottom right corner
          const logoX = canvas.width - logoWidth - 20;
          const logoY = canvas.height - logoHeight - 20;
          
          // Draw logo
          ctx.drawImage(logo, logoX, logoY, logoWidth, logoHeight);
          
          // Convert canvas to blob and resolve
          canvas.toBlob((blob) => {
            if (blob) {
              resolve(blob);
            } else {
              resolve(new Blob([]));
            }
          }, 'image/png');
        };
        
        logo.onerror = () => {
          console.error('Error loading logo image');
          // Still convert canvas to blob and resolve even if logo fails
          canvas.toBlob((blob) => {
            if (blob) {
              resolve(blob);
            } else {
              resolve(new Blob([]));
            }
          }, 'image/png');
        };
        
        logo.src = logoImage;
      } else {
        // No logo, convert canvas to blob and resolve
        canvas.toBlob((blob) => {
          if (blob) {
            resolve(blob);
          } else {
            resolve(new Blob([]));
          }
        }, 'image/png');
      }
    });
  };
  
  // Direct canvas rendering for cover slide
  const renderCoverSlideToCanvas = (): Promise<Blob> => {
    return new Promise((resolve) => {
      // Create canvas with Instagram dimensions
      const canvas = document.createElement('canvas');
      canvas.width = CAROUSEL_DIMENSIONS.width;
      canvas.height = CAROUSEL_DIMENSIONS.height;
      const ctx = canvas.getContext('2d');
      
      if (!ctx) {
        console.error('Could not get canvas context');
        resolve(new Blob([]));
        return;
      }
      
      // Fill background
      ctx.fillStyle = backgroundColor;
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      
      // Function to continue rendering after cover image is loaded (if any)
      const continueRendering = (coverImageHeight = 0, coverImageY = 0) => {
        // Set up text properties
        const fontSize = calculateFontSize(coverTitle) + 8;
        ctx.font = `bold ${fontSize}px ${fontStyle.name}`;
        ctx.fillStyle = fontColor;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        
        // Calculate text position (below cover image if exists)
        const textY = coverImageY + coverImageHeight + 50;
        
        // Draw title
        ctx.fillText(coverTitle || 'Cover Title', canvas.width / 2, textY);
        
        // Add logo if exists
        if (logoImage) {
          const logo = new Image();
          logo.onload = () => {
            // Calculate logo dimensions (75px height with proportional width)
            const logoHeight = 75;
            const logoWidth = (logo.width / logo.height) * logoHeight;
            
            // Position logo in bottom right corner
            const logoX = canvas.width - logoWidth - 20;
            const logoY = canvas.height - logoHeight - 20;
            
            // Draw logo
            ctx.drawImage(logo, logoX, logoY, logoWidth, logoHeight);
            
            // Convert canvas to blob and resolve
            canvas.toBlob((blob) => {
              if (blob) {
                resolve(blob);
              } else {
                resolve(new Blob([]));
              }
            }, 'image/png');
          };
          
          logo.onerror = () => {
            console.error('Error loading logo image');
            // Still convert canvas to blob and resolve even if logo fails
            canvas.toBlob((blob) => {
              if (blob) {
                resolve(blob);
              } else {
                resolve(new Blob([]));
              }
            }, 'image/png');
          };
          
          logo.src = logoImage;
        } else {
          // No logo, convert canvas to blob and resolve
          canvas.toBlob((blob) => {
            if (blob) {
              resolve(blob);
            } else {
              resolve(new Blob([]));
            }
          }, 'image/png');
        }
      };
      
      // Add cover image if exists
      if (coverImage) {
        const coverImg = new Image();
        coverImg.onload = () => {
          // Calculate cover image dimensions (max 300px height with proportional width)
          const maxHeight = 300;
          const scale = Math.min(1, maxHeight / coverImg.height);
          const imgWidth = coverImg.width * scale;
          const imgHeight = coverImg.height * scale;
          
          // Position image in center top area
          const imgX = (canvas.width - imgWidth) / 2;
          const imgY = (canvas.height - imgHeight) / 3; // Position in top third
          
          // Draw cover image
          ctx.drawImage(coverImg, imgX, imgY, imgWidth, imgHeight);
          
          // Continue rendering with cover image dimensions
          continueRendering(imgHeight, imgY);
        };
        
        coverImg.onerror = () => {
          console.error('Error loading cover image');
          // Continue rendering without cover image
          continueRendering();
        };
        
        coverImg.src = coverImage;
      } else {
        // No cover image, continue rendering
        continueRendering();
      }
    });
  };
  
  // Download carousel slides as images
  const downloadSlides = async () => {
    setIsDownloading(true);
    
    try {
      const zip = new JSZip();
      const slidePromises = [];
      
      console.log('Starting slide export process...');
      
      // Add cover slide if enabled
      if (hasCoverSlide) {
        console.log('Rendering cover slide...');
        const coverBlob = await renderCoverSlideToCanvas();
        console.log('Cover slide rendered, size:', coverBlob.size);
        zip.file('slide_00_cover.png', coverBlob);
      }
      
      // Add content slides
      for (let i = 0; i < slides.length; i++) {
        console.log(`Rendering slide ${i + 1}...`);
        const slidePromise = renderSlideToCanvas(slides[i], i).then(blob => {
          console.log(`Slide ${i + 1} rendered, size:`, blob.size);
          const slideNumber = (i + 1).toString().padStart(2, '0');
          zip.file(`slide_${slideNumber}.png`, blob);
        });
        
        slidePromises.push(slidePromise);
      }
      
      await Promise.all(slidePromises);
      console.log('All slides re<response clipped><NOTE>To save on context only part of this file has been shown to you. You should retry this tool after you have searched inside the file with `grep -n` in order to find the line numbers of what you are looking for.</NOTE>