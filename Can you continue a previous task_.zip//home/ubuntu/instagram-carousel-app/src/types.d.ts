declare module 'file-saver';
declare module 'jszip';
declare module 'html2canvas';
